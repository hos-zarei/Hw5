// HoseinZarei 40223038
#include <stdio.h>

int func(char *s, int n)
{
    for (int index = 0; index < n - 2; index++)
    {
        if (s[index] == s[index + 1] && s[index] != '\0')
        {
            for (int j = index; j <= n - 1; j++)
            {
                if (n + 2 > n - 1)
                {
                    s[j] = '\0';
                }
                s[j] = s[j + 2];
            }
            printf("%s\n", s);
            if (func(s, n) == 0)
            {
                return 1;
            }
        }
    }
    return 0;
}

int main()
{
    int n;
    printf("please enter your string length=");
    scanf("%d", &n);
    char s[n + 1];
    printf("please enter your string:");
    scanf("%s", s);
    func(s, n);
    if (func(s, n) == 0)
        printf("This phrase does not have consecutive common letters");
}